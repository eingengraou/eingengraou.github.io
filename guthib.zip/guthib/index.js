function menu(){
    $('.nav').toggleClass('show');
}