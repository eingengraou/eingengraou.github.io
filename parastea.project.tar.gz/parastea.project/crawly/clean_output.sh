#!/bin/bash

cp -r ./outputs/* ~/Pictures/x/
rm -rf ./outputs/*

echo '' > ./crawly.log
echo '' > ./visited.urls

