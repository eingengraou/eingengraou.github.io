from ioctools.www.url import Url
from ioctools.www.html import Parser
import aiohttp
import aiofiles
from ioctools.misc import ChunkReader
from typing import Any, Callable, Union, Collection


def filename(url: Url):
    parsed = url.parsed
    return "./output/" + parsed.netloc + "--" + parsed.path.replace("/", "_")


class TextHandler:
    def __init__(self):
        pass

    async def __call__(self, url, text):
        links = []
        link_parser = Parser(text)
        for link in link_parser.urls:
            linked_url = url.link_add(str(link))
            print(f"in: {str(url)} -> {str(linked_url)}")
            # await self.queue.put(linked_url)
            links.append(linked_url)

        return links


class ChunkHandler:
    def __init__(self, chunk_size):
        self.chunk_reader = ChunkReader(chunk_size)

    async def __call__(self, url, chunk, content: aiohttp.StreamReader):
        async with aiofiles.open(filename(url), mode='wb') as f:
            async for chunk in self.chunk_reader(content):
                await f.write(chunk)


class Handle:
    def __init__(self, handlers_text: Collection[TextHandler], handlers_binary: Collection[ChunkHandler]):
        self.handlers_text = handlers_text
        self.handlers_binary = handlers_binary

    async def __call__(self, url, response: aiohttp.ClientResponse):
        links = []
        if response.status == 200:
            content_type = response.headers.get('Content-Type')
            if 'text/html' in content_type:
                for handler in self.handlers_text:
                    print(f":: {str(url)}")
                    links = await handler(url, await response.text())
            else:
                for handler in self.handlers_binary:
                    async for chunk in handler.chunk_reader(response.content):
                        await handler(url, chunk, response.content)
        return links
