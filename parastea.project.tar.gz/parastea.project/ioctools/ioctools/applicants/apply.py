import typing
import asyncio
from ioctools.applicants.base import ApplyIO


class Apply(ApplyIO):
    pass
