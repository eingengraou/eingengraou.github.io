import asyncio
import pytest

from ioctools import tests


if __name__ == "__main__":
	pass
